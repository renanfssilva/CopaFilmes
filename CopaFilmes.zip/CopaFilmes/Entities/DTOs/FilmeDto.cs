﻿namespace Entities.DTOs
{
    public class FilmeDto
    {
        public string Id { get; set; }
        public string Titulo { get; set; }
        public int Ano { get; set; }
        public double Nota { get; set; }
    }
}
