﻿using System.Collections.Generic;

namespace Entities.Models
{
    public class Turno
    {
        public IEnumerable<Disputa> Disputas { get; set; }
    }
}
