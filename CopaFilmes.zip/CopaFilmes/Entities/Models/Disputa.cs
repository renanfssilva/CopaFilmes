﻿namespace Entities.Models
{
    public class Disputa
    {
        public Filme filme1 { get; set; }
        public Filme filme2 { get; set; }
    }
}
