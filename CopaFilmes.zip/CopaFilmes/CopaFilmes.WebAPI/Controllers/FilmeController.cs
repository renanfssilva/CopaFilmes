﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Contracts;
using Entities.DTOs;
using Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CopaFilmes.WebAPI.Controllers
{
    [ApiController]
    [Route("api")]
    public class FilmeController : ControllerBase
    {
        private const int quantidadeDeTurnos = 3;
        private readonly IFilmeRepository _filmeRepository;
        private readonly ILogger<FilmeController> _logger;
        private IMapper _mapper;

        public FilmeController(IFilmeRepository filmeRepository, ILogger<FilmeController> logger, IMapper mapper)
        {
            _filmeRepository = filmeRepository;
            _logger = logger;
            _mapper = mapper;
        }

        [Route("filmes")]
        [HttpGet]
        public IActionResult GetFilmes()
        {
            try
            {
                var filmes = _filmeRepository.GetFilmes();
                _logger.LogInformation("Todos os filmes da api foram consultados.");

                var filmesResult = _mapper.Map<IEnumerable<FilmeDto>>(filmes);
                return Ok(filmesResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Não foi possível consultar todos os filmes.\n{ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [Route("vencedores")]
        [HttpGet]
        public IActionResult GetVencedores([FromQuery]string[] idsSelecionados)
        {
            try
            {
                var filmesSelecionados = _filmeRepository.GetFilmesOrdenadosPorTitulo(idsSelecionados.ToList());
                _logger.LogInformation("Todos os ids de filmes foram consultados.");

                var filmesResult = _mapper.Map<IEnumerable<FilmeDto>>(filmesSelecionados);
                return Ok(filmesResult);
            }
            catch (Exception)
            {
                _logger.LogError("Não foi possível descobrir quais foram os finalistas do campeonato.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}